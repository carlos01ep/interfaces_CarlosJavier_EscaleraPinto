/**
 * Paquete que contiene los gráficos de la aplicacion
 */
package graficos;