/**
 * Paquete que contiene las imagenes de la aplicación
 */
package images;