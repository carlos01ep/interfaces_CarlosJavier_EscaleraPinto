/**
 * Paquete que contiene las clases auxiliares de utilidad
 */
package greenplanet.address.util;