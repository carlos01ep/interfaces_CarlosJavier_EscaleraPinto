/**
 * Paquete que contiene las clases modelo de la aplicación
 */
package greenplanet.address.model;