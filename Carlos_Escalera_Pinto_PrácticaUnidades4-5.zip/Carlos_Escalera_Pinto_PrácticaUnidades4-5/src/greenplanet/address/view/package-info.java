/**
 * Paquete que contiene los controladores y los diseños xml de la aplicación
 */
package greenplanet.address.view;