import java.util.Arrays;
import java.util.Scanner;

public class OrdenarNúmeros2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int contador = 0;
		int numero ;
		int[] numeros = new int[10];
		Scanner entrada = new Scanner(System.in);
		do{
			System.out.println("Para terminar de introducir numeros introduce un 0");
			numero = entrada.nextInt();
			numeros[contador] = numero;
			contador += 1;
		}
		while (numero != 0);
		Arrays.sort(numeros);
		for (int i = 0; i < numeros.length; i++) {
			if(numeros[i] != 0) {
				System.out.print(numeros[i] + " ");
			}	
		}
	}

}
